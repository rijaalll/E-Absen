const admin = require('firebase-admin');
const serviceAccount = require('./authKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://absen-app-dab6c-default-rtdb.asia-southeast1.firebasedatabase.app"
});

const db = admin.database();

module.exports = { admin, db };